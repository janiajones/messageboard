#Jania Jones
#04/23/23
#Section 009
#Assignment 9 Part 2

def valid_username(username):
    valid = True #giving base to start
    if len(username) < 5:
        valid = False #must be greater than or equal to 5
    if username.isalnum() == False:
        valid = False #only alphnum
    if len(username) > 0: #I made made this so empty string doesnt give error
        if username[0].isdigit() == True:
            valid = False #if it is true that 1st dig is num then valid is false
    return valid

def valid_password(password):
    valid = True #giving base to start
    if len(password) < 5:
        valid = False #must be greater than or equal to 5
    if password.isalnum() == False:
        valid = False #only alphnum
    if password.islower() == True:
        valid = False #we want at least one upper
    if password.isupper() == True:
        valid = False # we also want at least one lower
    if password.isalpha() == True:
        valid = False # we want at least one number
    if password.isdigit() == True:
        valid = False # we want a few letters
    return valid

#calling the imported file 
file_object = open('user_info.txt','r')
alldata = file_object.read()
file_object.close()

#breaking up the list in order to sep user and pass
splitdata = alldata.split('\n')
newlist = []
for value in splitdata:
    newlist += [value]


usernamelist = []
passwordlist =[]

#isolating username and password
for value in newlist:
    if value == '':
        valid = 'empty' #helping weed out empty string
    else:
        value1 = value.split(',')
        
        usernamelist += [value1[0]]#making new list for just user and just pass
        passwordlist += [value1[1]]

def username_exists(username): #new function
    #for i in range(len(usernamelist)): #running througj entire list
        #if username == '': #cancelling empty passwords
            #userexist = False
        #elif username in usernamelist: #comparing to see if in list
            #print(username)
            #userexist = True
            #break
        #else:
            #userexist = False
    if username in usernamelist: #simplified this bc it created an issue from blank list 
        userexist = True
    else:
        userexist = False
    return userexist #returning value

def send_message(sender, recipient, message): #i ended up
    #putting this beforethe add_user since I want to call this function in
    #add_user
    file_object = open('messages/'+recipient+'.txt', 'a') #opening my new folder
    import datetime #importing function to get the date of message time
    d = datetime.datetime.now()
    month = d.month
    day = d.day
    year = d.year
    hour = d.hour
    minute = d.minute
    second = d.second
    #end of date calculation 
    file_object.write(str(sender)+ '|')
    #formatting message information 
    file_object.write(str(month)+"/"+str(day)+"/"+str(year)+" "+str(hour)+":"+str(minute)+":"+str(second)+'|')
    file_object.write(message) #adding the message
    file_object.write('\n') #more formatting
    file_object.close()
    #print('Message sent!')
    
    
def add_user(username, password): #attempting to add values to the code
    valid = False
    global usernamelist #calling the variables from my previous functions
    global passwordlist
    #print(usernamelist)
    if username not in usernamelist: #only adding if not already there
        #print(username)
        usernamelist += [username] #adding to other list as well for
        #further reference
        passwordlist += [password]
        #appending the original file
        file_object = open('user_info.txt','a')
        file_object.write(username)
        file_object.write(",")
        file_object.write(password)
        # write a line break
        file_object.write("\n")
        file_object.close()
        send_message('admin',username, "Welcome to your account!")
        #from here above to append comment just adding the new inputs
        valid = True
    return valid

#i put this after add user so it would be incorporated to all the appropriate lists
def check_password(username, password): #checking if they match
   #inputcombo = []
   valid = False
   if (username in usernamelist) and (password in passwordlist):
       #checking to see if both inputs are even in the list to begin w 
       userlocation = usernamelist.index(username)
       passlocation = passwordlist.index(password)
       #finding the index of the values
       if userlocation == passlocation: #and then comapring them and if they match
           #then they are the same value/ correct input
           valid = True
   return valid

def print_messages(username): # print messages function
   sender = [] #blank lists to add in values for functions
   date = []
   message = []
   file_object = open('messages/'+username+'.txt', 'r')
   #opening another file
   alldata = file_object.read()
   alldatasplit = alldata.split('|') #splitting data with what has already been formatted
   newlist = [] #new blank list
   for value in alldatasplit:
       if '\n' in value:
          newlist += value.split('\n') #making new list to format again from strings
          #to account for line breaks in lists
       else:
          newlist += [value] #adding the values to the blank list so its
          #concatenated properly 
   for string in newlist:
       if newlist.index(string) == 0: #comparing the index so the first thing gets added first
           sender += [string]
       elif '/' in string: #using this to accomodate the date component
            date += [string]
       elif newlist.index(string) % 3 ==0: #this accomodates the strings
           sender += [string]
       else:
            message += [string] #left as an else statement for the rest of components to
            #fall in (aka the actual message)
   #print(message) 
   if message == []: # if message box empty
        print('No messages in your inbox')
        print()
   for i in range(len(message)): #running through all of the messages
        print("Message #",i+1, " recieved from ",sender[i],sep='') #formatting
        print("Time:",date[i])
        print(message[i])
        print()
   file_object.close() #closing file for end of function
   #no need to return anything because it is already printed 

def delete_messages(username):
    file_object = open('messages/'+username+'.txt', 'w')
    file_object.write("")
    #re-writes the function as nothing since 'w' wipes out whats there
    file_object.close()

while True:
    choice = input("(l)ogin, (r)egister or (q)uit: ") #main menu
    print()
    if choice == 'q':
        print('Goodbye!') #ending screen quitting
        break
    if choice == 'r':
        print('Register for an account') #formatting
        username = input('Username (case sensitive): ')
        if valid_username(username) == True: #validating username then pass for next step
            password = input('Password (case sensitive): ')
            if valid_password(password) == True: #valdiating password  
                if username_exists(username) == False:
                    add_user(username, password) #adding username to file 
                    print("Registration successful!")
                    print()
                else:
                    print("Duplicate username, registration cancelled")
                    print() #formatting 
            else:
                print('Password is invalid, registration cancelled')
                print()
        else:
            print('Password is invalid, registration cancelled')
            print()
            
    if choice == 'l': #choosing from main menu choice 1
        print('Log in')
        username = input('Username (case sensitive): ')
        if username_exists(username) == True: # testing output from return
            password = input('Password (case sensitive): ')
            if check_password(username,password) == True: #log in oppurtunity align/check
                while True:
                    print('You have been logged in successfully as',username)
                    choice2 = input('(r)ead messages, (s)end a message, (d)elete messages or (l)ogout: ')
                    if choice2 == 'r': #choice 1.1
                        print()
                        print_messages(username)
                    if choice2 == 's': #choice 1.2
                        recipient = input("Username of recipient: ")
                        if recipient not in usernamelist: #giving output if username isn't real 
                            #print(newlist)
                            print('Unknown recipient')
                        else:
                            message = input("Type your message: ")
                            send_message(username, recipient, message)
                            #calling the function from here w the data 
                            print('Message sent!')
                        print()
                    if choice2 == 'l': #choice 1.3
                        print('Logging out as username',username)
                        print()
                        break
                    if choice2 == 'd': #choice 1.4
                        delete_messages(username)
                        print('Your messages have been deleted')
                        print()


