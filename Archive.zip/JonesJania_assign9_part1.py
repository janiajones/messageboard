#Jania Jones
#04/20/23
#Section 009
#Assignment 9 Part 1

#calling the files
#course file
file_object = open('class_data.txt','r')
alldata = file_object.read()
#print(alldata)
file_object.close()
#student name file
file_object2 = open('enrollment_data.txt','r')
alldata2 = file_object2.read()
#print(alldata2)
file_object2.close()

#breaking the big list into a list of each name and its code
alldata = alldata.split('\n')
alldata2 = alldata2.split('\n')

code = [] #blank lists to add too
coursename =[]
for course in alldata: #breaking that into two lists of the codes and their names
    #print(course)
    splitcourse = course.split(",")
    code += [splitcourse[0]] #taking the index to make sure they line up in future
    coursename += [splitcourse[1]]
  
#while True: ## I wanted to try and make a loop so that the user could be prompted to check another
                # class but that wasn't in the instructions so I refrained from doing so
print("NYU Computer Science Registration System") #formatting
user_input = input("Enter a course ID (i.e. CS0002, CS0004): ") #user input
if user_input in code: #testing to see if class is valid
    index = coursename[code.index(user_input)]
    #creating index so we can find the name of the class
    print("The title of this class is:",index)
    names = [] #blank list for just their names
    count = 0 #blank count for students
    for value in alldata2: #running through all students in all programs
        if user_input in value: #specifying just to students in the class the user
            #inpuitted 
            names += [value[7:]] #adding selection of new strings to have list of
            #just names
            count += 1 #count for students in class
    print("The course has",count,"students enrolled")
    for name in names: #running another loop just to print their names
        print("*",name)
else: #validation
    print("Cannot find this course")


